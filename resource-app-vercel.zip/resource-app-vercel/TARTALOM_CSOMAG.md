# reSource – Magyar Péternek szóló email + Wix tartalom csomag

---

## 📧 EMAIL – Magyar Péternek (Complex Home együttműködés)

**Feladó:** hello@resourcestrategist.com  
**Tárgy:** reSource × Complex Home – együttműködési lehetőség

---

Kedves Péter,

Joó Gábor vagyok, a reSource platform alapítója.

A reSource egy önellátó rendszerekre fókuszáló platform, amely három egymást erősítő projektet fog össze: egy digitális épületfelmérő eszközt (reSource App), egy moduláris házépítési rendszert (Complex Home), és egy történelmi ingatlanok megújítására épülő hálózatot (Remonastère).

**Miért írok Neked?**

A Complex Home víziója – rezsimentes, önellátó, gyorsan felépíthető otthonok – pontosan illeszkedik abba a rendszerbe, amelyet a reSource platform épít. Nem versenytársak vagyunk, hanem egymást kiegészítő megközelítések:

- A **reSource App** digitálisan felméri a meglévő épületeket és megmutatja, milyen rendszerek kellene hozzá – ez leadeket és tudatosabb ügyfeleket generál
- A **Complex Home** azoknak ad választ, akik nem felújítani, hanem újat építeni szeretnének – önellátó, modern megoldással
- Mindkét projekt **ugyanazon technológiai partneri körre** épít: napelem, hőszivattyú, esővíz, hővisszanyerő szellőzés, akkumulátor

**Amit javaslok:**

Egy rövid egyeztetést, ahol megvitatjuk:
1. Hogyan tudna a reSource App leadeket irányítani a Complex Home felé
2. Milyen közös partneri megkereséseket tudnánk együtt végezni (gyártók, kivitelezők)
3. Hogyan erősítheti egymást a két brand a piacon

A reSource App jelenleg aktív fejlesztés alatt áll, az első tesztverzió elérhető itt:  
👉 **[resource-app link]**

Szívesen megmutatom a teljes platformot és a mögöttes logikát egy 30 perces online hívásban.

Mikor lenne jó Neked?

Üdvözlettel,
Joó Gábor
reSource | hello@resourcestrategist.com
www.resourcestrategist.com

---

## 🌐 WIX – reSource App szekció (az oldalba illeszthető szöveg)

### Főcím:
**reSource App**  
*Az épületed rendszerének digitális feltérképezője*

### Alcím:
Töltsd ki az épületed adatait – és 5 perc alatt megmutatjuk, milyen fejlesztésekkel lehetnél energetikailag önállóbb, mennyibe kerül, és mi a legjobb sorrend.

### Három érték pont:
🏠 **Épületre szabva** – nem általános tippek, hanem a te házadhoz illesztett javaslatok  
⚡ **Energetikai besorolás** – megmutatjuk hol állsz most és hova juthatnál  
⬇️ **Letölthető összefoglaló** – minden javaslattal, beruházási költséggel és megtérüléssel

### CTA gomb szöveg:
**Indítsd el a felmérést →**  
*(link: [Vercel app URL])*

### Megjegyzés a gomb alá (kis szöveg):
Ingyenes · 5–8 perc · Letölthető eredmény

---

## 📱 APP STORE – jövőbeli leírás (előkészítve)

**App neve:** reSource App  
**Kategória:** Utilities / Productivity  
**Rövid leírás (30 karakter):** Épületed energetikai terve  
**Hosszú leírás:**

A reSource App segít megérteni, hol veszíti el energiáját az épületed – és megmutatja, mit tehetsz ellene.

Töltsd ki az épületed adatait (típus, kor, szigetelés, fűtés, fogyasztás), és személyre szabott fejlesztési tervet kapsz: prioritási sorrendben, beruházási költségekkel és megtérülési időkkel.

Funkciók:
• Két flow: lakóépület és vállalkozás
• Energetikai besorolás – jelenlegi és felújítás utáni
• Letölthető HTML összefoglaló
• Complex Home és Remonastère integrált ajánlat
• Magyar és angol nyelvű verzió (hamarosan)

A reSource App a reSource platform része – ahol a digitális eszköz, a moduláris építés és a történelmi ingatlanok megújítása egyetlen rendszerbe kapcsolódik.

---

## 🔧 VERCELRE FELTÖLTÉS – lépések

1. Menj a https://vercel.com oldalra és regisztrálj (ingyenes, Google-lel is megy)
2. Kattints: "Add New Project"
3. Húzd fel a resource-app-vercel mappát (zip-ként is feltölthető)
4. Build settings: Framework = Create React App (automatikusan felismeri)
5. Deploy → kapsz egy URL-t: pl. resource-app.vercel.app
6. Ezt az URL-t tedd be a Wix gombba és az emailbe

**Vagy:** Küld el nekem és én segítek a deploy-ban is.

---

*Elkészítette: reSource / Claude – 2025*
